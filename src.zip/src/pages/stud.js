import React, {useState} from 'react';
import {Link} from "react-router-dom";
import {Button, ListGroup, ListGroupItem} from "react-bootstrap"
import data from "../all.json";
import here_list from "../today.json";

const Stud = () => {
    const [color, setColor] = useState('white')
    let data = require('/Users/adalabilbekov/Desktop/attendance2/src/all.json')
    let here_list = require('/Users/adalabilbekov/Desktop/attendance2/src/today.json')
    let data_2 = []
    let here_list_2 = []
    for (let i = 0; i< data.length; i++){
        data_2.push(data[i].name)
    }
    for (let i = 0; i< here_list.length; i++){
        here_list_2.push(here_list[i].name)
    }
    for (let i = 0; i< data_2.length - here_list_2.length; i++){
        here_list_2.push('')
    }

    const changeColor = () => setColor('black')
    let is_here = []
    for (let i =0; i < data_2.length; i++){
        is_here.push([data_2[i] === here_list_2[i], data_2[i]])
    }
    let bord = "1px solid " + color
    return (<ListGroup as="ol" numbered>
        <Button onClick={() => {changeColor()}}>Start the lesson</Button>
            <ListGroupItem style={{color:"Black"}}> All Students: </ListGroupItem>
    {is_here.map( student => (
        (student[0]) ?
            <ListGroupItem style={{color:color, borderBottom:bord}} as="li">{student[1]} Present</ListGroupItem>
            :
            <ListGroupItem style={{color:color, borderBottom:bord}} as="li">{student[1]} Absent</ListGroupItem>
    ))}</ListGroup>
    );
};
export default Stud;