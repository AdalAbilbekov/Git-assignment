import auth from "./pages/auth";
import stud from "./pages/stud";

export const publicRoutes = [
    {path:'/', Component:auth},
    {path:'/student', Component:stud}
]